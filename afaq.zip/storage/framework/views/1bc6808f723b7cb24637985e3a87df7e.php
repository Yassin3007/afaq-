
<?php $__env->startSection('content'); ?>


  <!--/ Intro Skew Star /-->
  <div class="intro intro-single route bg-image" style="background-image: url(img-3.jpg);height: 100px;">
    <div class="overlay-mf"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <h2 class="intro-title mb-4"> </h2>
          
        </div>
      </div>
    </div>
  </div>
  <!--/ Intro Skew End /-->

  <!--/ Section Blog-Single Star /-->
  <section class="blog-wrapper sect-pt4" style="direction: rtl;" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
     
          <div class="box-comments" style="direction: rtl;">
            <div class="title-box-2">
              <h4 class="title-comments title-left" style="text-align: right;"> اسماء الشركات </h4>
            </div>
            <table class="table table-hover" style="text-align: right;">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">لوجو الشركة</th>
                  <th scope="col">اسم الشركة</th>
                  <th scope="col">النوع</th>
                  <th scope="col">رابط التقديم</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($loop->iteration); ?></th>
               
                  <td>
                    <img src="<?php echo e(( $company->logo!== null)? asset('images/'.$company->logo):asset('front/img/x.png')); ?>" style="margin-left: 20px;width: 60px;height: 60px; "  alt="">

                  </td>
                  <td><?php echo e($company->name); ?></td>
                  <td><?php echo e($company->type); ?></td>
                  <td>
                    <a href="<?php echo e($company->link); ?>"><?php echo e($company->link); ?></a>
                    </td>
           
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            
              </tbody>
            </table>
          </div>
      
        </div>
     
      </div>
    </div>
  </section>
  <!--/ Section Blog-Single End /-->

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\afaq\resources\views/front/job/companies.blade.php ENDPATH**/ ?>