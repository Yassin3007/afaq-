
<?php $__env->startSection('content'); ?>
    
  <!--/ Intro Skew Star /-->
  <div id="home" class="intro route bg-image" style="background-image: url(<?php echo e(asset('front/img/work-3.jpg')); ?>); direction: rtl;">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4" style="text-align: right;">منصة افاق   </h1>
          <p class="intro-subtitle"><span class="text-slider-items"> لدعم الخريجين </span><strong class="text-slider"></strong></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div>
  <!--/ Intro Skew End /-->

<br>

  <!--/ Section Services Star /-->
  <section id="service" class="services-mf route" style="direction: rtl;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              المسارات
            </h3>
           
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <a href="<?php echo e(route('training_route')); ?>">

          <div class="service-box" >
            <div class="service-ico">
              <!-- <span class="ico-circle"><i class="ion-monitor"></i></span> -->
              <span >
                <!-- <span class="ico-circle"> -->
                <img src="<?php echo e(asset('front/img/1M.png')); ?>" width="90%" alt="">
              </span>
            </div>
            <div class="service-content">
              <h2 class="s-title"> <?php echo e($training->name); ?> </h2>
              <p class="s-description text-center">
                <?php echo e($training->description); ?>

            </p>
            </div>
          </div>
        </a>

        </div>

        <div class="col-md-4" >
          <a href="<?php echo e(route('education_route')); ?>">

          <div class="service-box" >
            <div class="service-ico">
              <!-- <span class="ico-circle"><i class="ion-code-working"></i></span> -->
              <span >
                <img src="<?php echo e(asset('front/img/2M.png')); ?>" width="90%" alt="">
              </span>
            </div>
            <div class="service-content">
              <h2 class="s-title"> <?php echo e($edu->name); ?> </h2>
              <p class="s-description text-center">
                <?php echo e($edu->description); ?>

              </p>
            </div>
          </div>
        </a>

        </div>
        <div class="col-md-4">
          <a href="<?php echo e(route('job_route')); ?>">

          <div class="service-box" >
            <div class="service-ico">
              <!-- <span class="ico-circle"><i class="ion-camera"></i></span> -->
              <span >
                <img src="<?php echo e(asset('front/img/3M.png')); ?>" width="90%" alt="">
              </span>
            </div>
            <div class="service-content">
              <h2 class="s-title"><?php echo e($job->name); ?> </h2>
              <p class="s-description text-center">
                <?php echo e($job->description); ?>

              </p>
            </div>
          </div>
        </a>

        </div>
    
      </div>
    </div>
  </section>
  <!--/ Section Services End /-->

  <!--/ Section Blog Star /-->
  <section id="blog" class="blog-mf sect-pt4 route" style="direction: rtl;text-align: right;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              أحدث المقالات 
            </h3>
        
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="col-md-4">
          <div class="card card-blog">
            <div class="card-img">
              <a href="blog-single.html"><img src="<?php echo e(asset('images/'. $article->logo)); ?>" alt="" class="img-fluid"></a>
            </div>
            <div class="card-body">
              <div class="card-category-box">
                <div class="card-category">
                  
                </div>
              </div>
              <h3 class="card-title"><a href="<?php echo e(route('get_articles')); ?>"><?php echo e($article->name); ?>  </a></h3>
              <p class="card-description">


              </p>
            </div>
            <div class="card-footer">
             
              
             
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    
 
      </div>
    </div>
  </section>
  <!--/ Section Blog End /-->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\afaq\resources\views/front/index.blade.php ENDPATH**/ ?>