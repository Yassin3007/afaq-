
<?php $__env->startSection('content'); ?>


  <!--/ Intro Skew Star /-->
  <div class="intro intro-single route bg-image" style="background-image: url(img-3.jpg);height: 100px;">
    <div class="overlay-mf"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <h2 class="intro-title mb-4"> </h2>
          
        </div>
      </div>
    </div>
  </div>
  <!--/ Intro Skew End /-->

  <!--/ Section Blog-Single Star /-->
  <section class="blog-wrapper sect-pt4" style="direction: rtl;" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
     
          <div class="box-comments" style="direction: rtl;">
            <div class="title-box-2">
              <h4 class="title-comments title-left" style="text-align: right;"> الفرص الوظيفية الشاغرة </h4>
            </div>
            <ul style="text-align: right;" class="list-comments">
              <?php $__currentLoopData = $opportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                <div class="comment-avatar">
                  <img src="<?php echo e(asset('images/'.$opportunity->logo)); ?>" style="margin-left: 20px; "  alt="">
                </div>
                <div class="comment-details">
                  <h4 class="comment-author"><?php echo e($opportunity->title); ?></h4>
                  <span style="color: rgb(0, 60, 255)"><?php echo e($opportunity->start); ?> - <?php echo e($opportunity->end); ?></span><br>

                  <?php if($opportunity->start<= date('Y-m-d') && $opportunity->end > date('Y-m-d')): ?>
                  <span class="badge badge-success">متاحة الان</span>

                  <?php else: ?>
                  <span class="badge badge-danger">غير متاحة  </span>

                  <?php endif; ?>
                  <br>
                  <span>  <?php echo e($opportunity->company_name); ?></span>
                  <p>
                    <?php echo e(\Illuminate\Support\Str::limit($opportunity->description  ,150)); ?>

                    
                  </p>
                  <a href="<?php echo e(route('job',$opportunity->id)); ?>">عرض التفاصيل</a>
                </div>
              </li> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
      
            </ul>
          </div>
      
        </div>
        <div class="col-md-4">
     
          <div class="box-comments" style="direction: rtl; padding-left: 0;">
            <div class="title-box-2">
              <h6 class="title-comments title-left" style="text-align: right;"> اسماء الشركات </h6>
            </div>
            <ul style="text-align: right;padding-right: 0; "  class="list-comments">
              <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                <div class="comment-avatar">
                  <img src="<?php echo e(( $company->logo!== null)? asset('images/'.$company->logo):asset('front/img/x.png')); ?>" style="margin-left: 20px;width: 60px;height: 60px; "  alt="">
                </div>
                <div class="comment-details" style="padding-left: 0;">
                  
                  <a href="<?php echo e($company->link); ?>" style="font-size: 15px;padding-left: 0;">
                    <?php echo e($company->name); ?> 

                  </a>
                  <p> <?php echo e($company->type); ?></p>

                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
         
              <a href="<?php echo e(route('all_companies')); ?>"  class="btn btn-outline-primary button-rouded" >عرض كل الشركات</a>

          
      
            </ul>
            
          </div>
          <a href="<?php echo e(asset('images/'.$file)); ?>"   target="_blank" >تحميل ملف الشركات </a>

        </div>
     
      </div>
    </div>
  </section>
  <!--/ Section Blog-Single End /-->

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\afaq\resources\views/front/job/index.blade.php ENDPATH**/ ?>