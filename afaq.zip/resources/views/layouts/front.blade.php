<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>منصة آفاق</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css2?family=Overpass:ital,wght@0,100;0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@700&display=swap">
 
  <!-- Bootstrap CSS File -->
  <link href="{{asset('public/front/lib/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="{{asset('public/front/lib/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
  <link href="{{asset('public/front/lib/animate/animate.min.css')}}" rel="stylesheet">
  <link href="{{asset('public/front/lib/ionicons/css/ionicons.min.css')}}" rel="stylesheet">
  <link href="{{asset('public/front/lib/owlcarousel/assets/owl.carousel.min.css')}}" rel="stylesheet">
  <link href="{{asset('public/front/lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="{{asset('public/front/css/style.css')}}" rel="stylesheet">

  <!-- =======================================================
    Theme Name: DevFolio
    Theme URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<style>
  body {
   font-family: 'Tajawal', sans-serif;
 font-weight: 700; /* استخدام النمط السميك */  }



 </style>
<body id="page-top" >

  <!--/ Nav Star /-->
  <nav class="navbar navbar-b navbar-trans navbar-expand-md fixed-top" id="mainNav">
    <div class="container">
<a class="navbar-brand js-scroll" href="{{route('index')}}">
      <img src="{{asset('public/front/img/afaaq.png')}}" alt="" width="100px">
      </a>      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
        aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-collapse collapse justify-content-end" id="navbarDefault">
        <ul class="navbar-nav" style="direction: rtl;">
          <li class="nav-item">
            <a class="nav-link js-scroll active" href="{{route('index')}}">الرئيسية</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="{{route('training_route')}}">مسار التدريب</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="{{route('education_route')}}">مسار التعليم</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="{{route('job_route')}}">مسار التوظيف</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="{{route('get_articles')}}">المقالات  </a>
          </li>
      
          <li class="nav-item">
            <a class="nav-link js-scroll" href="{{route('contact')}}">تواصل معنا</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!--/ Nav End /-->
 
  @yield('content')
  <!--/ Section Contact-Footer Star /-->
  <section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(img/overlay-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="contact-mf">
        
          </div>
        </div>
      </div>
    </div>
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="copyright-box">
              <p class="copyright">&copy; Copyright <strong>آفاق</strong>. All Rights Reserved</p>
              <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=DevFolio
                -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </section>
  <!--/ Section Contact-footer End /-->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="{{asset('public/front/lib/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('public/front/lib/jquery/jquery-migrate.min.js')}}"></script>
  <script src="{{asset('public/front/lib/popper/popper.min.js')}}"></script>
  <script src="{{asset('public/front/lib/bootstrap/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('public/front/lib/easing/easing.min.js')}}"></script>
  <script src="{{asset('public/front/lib/counterup/jquery.waypoints.min.js')}}"></script>
  <script src="{{asset('public/front/lib/counterup/jquery.counterup.js')}}"></script>
  <script src="{{asset('public/front/lib/owlcarousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('public/front/lib/lightbox/js/lightbox.min.js')}}"></script>
  <script src="{{asset('public/front/lib/typed/typed.min.js')}}"></script>
  <!-- Contact Form JavaScript File -->
  {{-- <script src="{{asset('public/front/contactform/contactform.js')}}"></script> --}}

  <!-- Template Main Javascript File -->
  <script src="{{asset('public/front/js/main.js')}}"></script>


  <!--<script>-->
  <!--  window.onload = function() {-->
  <!--    var allAnchorTags = document.querySelectorAll('a');-->
  <!--    for (var i = 0; i < allAnchorTags.length; i++) {-->
  <!--      allAnchorTags[i].setAttribute('target', '_blank');-->
  <!--    }-->
  <!--  };-->
  <!--</script>-->


</body>
</html>
